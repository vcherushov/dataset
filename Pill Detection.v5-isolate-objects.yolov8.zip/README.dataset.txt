# Pill Detection > isolate-objects
https://universe.roboflow.com/mohamed-attia-e2mor/pill-detection-llp4r

Provided by a Roboflow user
License: Public Domain

## Background Information
This dataset was curated and annotated by [Mohamed Attia](https://www.linkedin.com/in/mohamed-attia-aa274a193/).

The original dataset *(v1)* is composed of 451 images of various pills that are present on a large variety of surfaces and objects.
![Example of an Annotated Image from the Dataset](https://i.imgur.com/shZh1DV.jpeg)

The dataset is available under the Public License.

## Getting Started
You can download this dataset for use within your own projects, or fork it into a workspace on Roboflow to create your own model.

## Dataset Versions
### Version 1 (v1) - 451 images
* Preprocessing: Auto-Orient and Resize (Stretch to 416x416)
* Augmentations: *No augmentations applied*
* Training Metrics: *This version of the dataset was not trained*

### Version 2 (v2) - 1,083 images
* Preprocessing: Auto-Orient, Resize (Stretch to 416x416), all classes remapped (Modify Classes) to "pill"
* Augmentations:
90° Rotate: Clockwise, Counter-Clockwise, Upside Down
Crop: 0% Minimum Zoom, 77% Maximum Zoom
Rotation: Between -45° and +45°
Shear: ±15° Horizontal, ±15° Vertical
Hue: Between -22° and +22°
Saturation: Between -27% and +27%
Brightness: Between -33% and +33%
Exposure: Between -25% and +25%
Blur: Up to 3px
Noise: Up to 5% of pixels
Cutout: 3 boxes with 10% size each
Mosaic: Applied
Bounding Box: Brightness: Between -25% and +25%
* Training Metrics: Trained from the COCO Checkpoint in Public Models ("[transfer learning](https://blog.roboflow.com/a-primer-on-transfer-learning/)") on Roboflow
	* mAP = 91.4%, precision = 61.1%, recall = 93.9%

### Version 3 (v3) - 1,083 images
* Preprocessing: Auto-Orient, Resize (Stretch to 416x416), all classes remapped (Modify Classes) to "pill"
* Augmentations:
90° Rotate: Clockwise, Counter-Clockwise, Upside Down
Crop: 0% Minimum Zoom, 77% Maximum Zoom
Rotation: Between -45° and +45°
Shear: ±15° Horizontal, ±15° Vertical
Hue: Between -22° and +22°
Saturation: Between -27% and +27%
Brightness: Between -33% and +33%
Exposure: Between -25% and +25%
Blur: Up to 3px
Noise: Up to 5% of pixels
Cutout: 3 boxes with 10% size each
Mosaic: Applied
Bounding Box: Brightness: Between -25% and +25%
* Training Metrics: Trained from "scratch" (no transfer learning employed) on Roboflow
	* mAP = 84.3%, precision = 53.2%, recall = 86.7%

### Version 4 (v4) - 451 images
* Preprocessing: Auto-Orient, Resize (Stretch to 416x416), all classes remapped (Modify Classes) to "pill"
* Augmentations: *No augmentations applied*
* Training Metrics: *This version of the dataset was not trained*

### Version 5 (v5) - 496 images
* Preprocessing: Auto-Orient, all classes remapped (Modify Classes) to "pill", [Isolate Objects](https://blog.roboflow.com/isolate-objects/)
	* The Isolate Objects preprocessing step was added to convert this object detection project into a suitable format for export in OpenAI's CLIP annotation format so that it could be used as a classifcation model (classification dataset available here: https://universe.roboflow.com/mohamed-attia-e2mor/pill-classification)

Mohamed Attia - [LinkedIn](https://www.linkedin.com/in/mohamed-attia-aa274a193/)